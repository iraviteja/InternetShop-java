package com.global;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.CardLayout;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import javax.swing.JTextField;

import net.proteanit.sql.DbUtils;

import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.SystemColor;

public class AdminFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextField textField;
	private JPasswordField passwordField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTable table_1;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JTable table;
	private JTextField username;
	private JTextField password;
	private JTextField database;
	private JTextField path;
	private JTable table_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminFrame frame = new AdminFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws IOException 
	 */
	public AdminFrame() throws IOException {
		
		setTitle("Internet shop management system");
	    setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 698, 485);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNavigation = new JMenu("Navigation");
		menuBar.add(mnNavigation);
		
		JMenuItem mntmMainpage = new JMenuItem("Mainpage");
		mntmMainpage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				((CardLayout)AdminFrame.this.getContentPane().getLayout()).show(AdminFrame.this.getContentPane(), "name_46642539883279");
			}
		});
		mnNavigation.add(mntmMainpage);
		
		JMenuItem mntmExit = new JMenuItem("Exit");
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		mnNavigation.add(mntmExit);
		
		JMenu mnUsers = new JMenu("Users");
		menuBar.add(mnUsers);
		
		JMenuItem mntmAddUser = new JMenuItem("Add user");
		mntmAddUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				((CardLayout)AdminFrame.this.getContentPane().getLayout()).show(AdminFrame.this.getContentPane(), "name_47052913768088");
				
			}
		});
		mnUsers.add(mntmAddUser);
		
		JMenuItem mntmDeleteUser = new JMenuItem("Delete user");
		mntmDeleteUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				((CardLayout)AdminFrame.this.getContentPane().getLayout()).show(AdminFrame.this.getContentPane(), "name_48910390499538");
				
			}
		});
		mnUsers.add(mntmDeleteUser);
		
		JMenuItem mntmViewUsers = new JMenuItem("View Users");
		mntmViewUsers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				((CardLayout)AdminFrame.this.getContentPane().getLayout()).show(AdminFrame.this.getContentPane(), "name_83001145966560");	
			}
		});
		mnUsers.add(mntmViewUsers);
		
		JMenu mnExpenditures = new JMenu("Expenditures");
		menuBar.add(mnExpenditures);
		
		JMenuItem mntmAddExpenditures = new JMenuItem("Add Expenditures");
		mntmAddExpenditures.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((CardLayout)AdminFrame.this.getContentPane().getLayout()).show(AdminFrame.this.getContentPane(), "name_51935305444630");	
				
			}
		});
		mnExpenditures.add(mntmAddExpenditures);
		
		JMenuItem mntmViewExpenditures = new JMenuItem("View Expenditures");
		mntmViewExpenditures.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				((CardLayout)AdminFrame.this.getContentPane().getLayout()).show(AdminFrame.this.getContentPane(), "name_54095867463309");	
			}
		});
		mnExpenditures.add(mntmViewExpenditures);
		
		JMenu mnIncome = new JMenu("Income");
		menuBar.add(mnIncome);
		
		JMenuItem mntmAddData = new JMenuItem("Add data");
		mntmAddData.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				((CardLayout)AdminFrame.this.getContentPane().getLayout()).show(AdminFrame.this.getContentPane(), "name_56397118168204");	
			}
		});
		mnIncome.add(mntmAddData);
		
		JMenuItem mntmView = new JMenuItem("View data");
		mntmView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				((CardLayout)AdminFrame.this.getContentPane().getLayout()).show(AdminFrame.this.getContentPane(), "name_56537014371751");
			}
		});
		mnIncome.add(mntmView);
		
		JMenu mnLicenseDetails = new JMenu("License Details");
		menuBar.add(mnLicenseDetails);
		
		JMenuItem mntmCheckDetails = new JMenuItem("Check details");
		mntmCheckDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				((CardLayout)AdminFrame.this.getContentPane().getLayout()).show(AdminFrame.this.getContentPane(), "name_81876720356599");
			}
		});
		mnLicenseDetails.add(mntmCheckDetails);
		
		JMenu mnOthers = new JMenu("Others");
		menuBar.add(mnOthers);
		
		JMenuItem mntmDataBackup = new JMenuItem("Data Backup");
		mntmDataBackup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				((CardLayout)AdminFrame.this.getContentPane().getLayout()).show(AdminFrame.this.getContentPane(), "name_59650634978400");	
				
			}
		});
		mnOthers.add(mntmDataBackup);
		
		JMenu mnHelp = new JMenu("Help");
		menuBar.add(mnHelp);
		
		JMenuItem mntmAbout = new JMenuItem("About");
		mntmAbout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				JOptionPane.showMessageDialog(null, "                       v 1.0", "Software Version", 1);
			}
		});
		mnHelp.add(mntmAbout);
		getContentPane().setLayout(new CardLayout(0, 0));
		
		JPanel panel = new JPanel();
		getContentPane().add(panel, "name_46642539883279");
		panel.setLayout(null);
		
		JButton btnNewButton_2 = new JButton("Net Profit");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				    int sum_exp = 0;
			        int sum_sal = 0;
			        int sum_total = 0;
			        
			        Connection con = null;
			        Statement st = null;
			        String url = "jdbc:mysql://localhost:3306/internet_shop";
			        String user = "root";
			        String password = "";
			        try
			        {
			          Class.forName("com.mysql.jdbc.Driver");
			          con = DriverManager.getConnection(url, user, password);
			          st = con.createStatement();
			          
			          String sql = "SELECT SUM(amount) FROM expenditures ";
			          ResultSet rs = st.executeQuery(sql);
			          while (rs.next())
			          {
			            int c = rs.getInt(1);
			            sum_exp += c;
			          }
			          rs.close();
			          st.close();
			          con.close();
			        }
			        catch (SQLException se)
			        {
			          se.printStackTrace();
			        }
			        catch (Exception e1)
			        {
			          e1.printStackTrace();
			        }
			        Connection con1 = null;
			        Statement st1 = null;
			        String url1 = "jdbc:mysql://localhost:3306/internet_shop";
			        String user1 = "root";
			        String password1 = "";
			        try
			        {
			          Class.forName("com.mysql.jdbc.Driver");
			          con1 = DriverManager.getConnection(url1, user1, password1);
			          st1 = con1.createStatement();
			          
			          String sql1 = "SELECT SUM(amount) FROM income ";
			          ResultSet rs = st1.executeQuery(sql1);
			          while (rs.next())
			          {
			            int c = rs.getInt(1);
			            sum_sal += c;
			          }
			          rs.close();
			          st.close();
			          con.close();
			        }
			        catch (SQLException se)
			        {
			          se.printStackTrace();
			        }
			        catch (Exception e1)
			        {
			          e1.printStackTrace();
			        }
			        sum_total = sum_sal - sum_exp;
			        JOptionPane.showMessageDialog(null, "Your net Profit is " + sum_total + " ");
			      }
				
			
		});
		btnNewButton_2.setBounds(452, 142, 116, 31);
		panel.add(btnNewButton_2);
		
		JLabel lblPoweredBySyzant = new JLabel("Powered by Syzant");
		lblPoweredBySyzant.setForeground(SystemColor.textHighlight);
		lblPoweredBySyzant.setBounds(10, 410, 149, 14);
		panel.add(lblPoweredBySyzant);
		
		JLabel lblNewLabel_1 = new JLabel("Welcome to Admin Panel");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 19));
		lblNewLabel_1.setForeground(new Color(30, 144, 255));
		lblNewLabel_1.setBounds(43, 95, 269, 64);
		panel.add(lblNewLabel_1);
		
		JButton btnNewButton_3 = new JButton("Expenditures");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				int sum_exp = 0;
		        
		        
		        Connection con = null;
		        Statement st = null;
		        String url = "jdbc:mysql://localhost:3306/internet_shop";
		        String user = "root";
		        String password = "";
		        try
		        {
		          Class.forName("com.mysql.jdbc.Driver");
		          con = DriverManager.getConnection(url, user, password);
		          st = con.createStatement();
		          
		          String sql = "SELECT SUM(amount) FROM expenditures ";
		          ResultSet rs = st.executeQuery(sql);
		          while (rs.next())
		          {
		            int c = rs.getInt(1);
		            sum_exp += c;
		          }
		          JOptionPane.showMessageDialog(null, "Your total expenditures is " + sum_exp + " ");
		          rs.close();
		          st.close();
		          con.close();
		        }
		        catch (SQLException se)
		        {
		          se.printStackTrace();
		        }
		        catch (Exception e1)
		        {
		          e1.printStackTrace();
		        }
		        
				
			}
		});
		btnNewButton_3.setBounds(452, 206, 116, 31);
		panel.add(btnNewButton_3);
		
		JLabel lblQuickLinks = new JLabel("Quick Operations :");
		lblQuickLinks.setFont(new Font("Tahoma", Font.ITALIC, 15));
		lblQuickLinks.setForeground(new Color(106, 90, 205));
		lblQuickLinks.setBounds(445, 75, 136, 24);
		panel.add(lblQuickLinks);
		
		JButton btnNewButton_4 = new JButton("Income");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				

				int sum_inc = 0;
		        
		        
		        Connection con = null;
		        Statement st = null;
		        String url = "jdbc:mysql://localhost:3306/internet_shop";
		        String user = "root";
		        String password = "";
		        try
		        {
		          Class.forName("com.mysql.jdbc.Driver");
		          con = DriverManager.getConnection(url, user, password);
		          st = con.createStatement();
		          
		          String sql = "SELECT SUM(amount) FROM income ";
		          ResultSet rs = st.executeQuery(sql);
		          while (rs.next())
		          {
		            int c = rs.getInt(1);
		            sum_inc += c;
		          }
		          JOptionPane.showMessageDialog(null, "Your total income is " + sum_inc + " ");
		          rs.close();
		          st.close();
		          con.close();
		        }
		        catch (SQLException se)
		        {
		          se.printStackTrace();
		        }
		        catch (Exception e1)
		        {
		          e1.printStackTrace();
		        }
		        
			}
		});
		btnNewButton_4.setBounds(452, 274, 116, 31);
		panel.add(btnNewButton_4);
		
		JLabel lblSaiInternetShop_1 = new JLabel("Sai Internet shop");
		lblSaiInternetShop_1.setForeground(new Color(165, 42, 42));
		lblSaiInternetShop_1.setFont(new Font("Rockwell", Font.BOLD, 16));
		lblSaiInternetShop_1.setBounds(86, 208, 149, 23);
		panel.add(lblSaiInternetShop_1);
		
		JPanel panel_1 = new JPanel();
		getContentPane().add(panel_1, "name_47052913768088");
		panel_1.setLayout(null);
		
		JLabel lblUsername = new JLabel("Username : ");
		lblUsername.setBounds(274, 131, 70, 14);
		panel_1.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password :");
		lblPassword.setBounds(274, 183, 70, 14);
		panel_1.add(lblPassword);
		
		JLabel lblAddUser = new JLabel("Add User ");
		lblAddUser.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblAddUser.setForeground(Color.BLUE);
		lblAddUser.setBounds(357, 73, 89, 28);
		panel_1.add(lblAddUser);
		
		textField = new JTextField();
		textField.setBounds(392, 128, 86, 20);
		panel_1.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(392, 180, 86, 20);
		panel_1.add(passwordField);
		
		JButton btnNewButton = new JButton("Add user");
		btnNewButton.addActionListener(new ActionListener() {
			 public void actionPerformed(ActionEvent e) {
				 
				 
				    String user1 = AdminFrame.this.textField.getText();
				    String pass = String.valueOf(AdminFrame.this.passwordField.getPassword());
			       
				 
			      Connection con = null;				  
		          Statement st1 = null;
		          String url = "jdbc:mysql://localhost:3306/internet_shop";
		          String user = "root";
		          String password = "";
				 
				 try
		          {
		            Class.forName("com.mysql.jdbc.Driver");
		            con = DriverManager.getConnection(url, user, password);
		            st1 = con.createStatement(); 
		            String sql1 = " INSERT INTO user_table (username,password) VALUES ('" + user1 + "','" + pass + "')";
		            int rs1 = st1.executeUpdate(sql1);
		            
		            if (rs1 == 1)
		            {
		              AdminFrame.this.textField.setText("");
		              AdminFrame.this.passwordField.setText("");
		              JOptionPane.showMessageDialog(null, "User Added successfully");
		            }
		            else 
		            {	
		        
                    JOptionPane.showMessageDialog(null, "Sorry something went wrong");
		          
		             
		              }
		          }
				 
				 
				 catch (SQLException se)
		          {
		            se.printStackTrace();
		          } catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		          
			 }
		});
		btnNewButton.setBounds(321, 228, 89, 23);
		panel_1.add(btnNewButton);
		
		JLabel label = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/plus.png")).getImage();
		label.setIcon(new ImageIcon(img));
		label.setBounds(52, 113, 163, 149);
		panel_1.add(label);
		
		JPanel panel_2 = new JPanel();
		getContentPane().add(panel_2, "name_48910390499538");
		panel_2.setLayout(null);
		
		JLabel lblDeleteUser = new JLabel("Delete User :");
		lblDeleteUser.setForeground(Color.BLUE);
		lblDeleteUser.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblDeleteUser.setBounds(338, 109, 105, 14);
		panel_2.add(lblDeleteUser);
		
		JLabel lblUsername_1 = new JLabel("Username :");
		lblUsername_1.setBounds(275, 168, 67, 14);
		panel_2.add(lblUsername_1);
		
		textField_1 = new JTextField();
		textField_1.setBounds(390, 165, 86, 20);
		panel_2.add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnDeleteUser = new JButton("Delete User");
		btnDeleteUser.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String username = AdminFrame.this.textField_1.getText();
				
				  Connection con = null;				  
		          Statement st1 = null;
		          String url = "jdbc:mysql://localhost:3306/internet_shop";
		          String user = "root";
		          String password = "";
				 
				 try
		          {
		            Class.forName("com.mysql.jdbc.Driver");
		            con = DriverManager.getConnection(url, user, password);
		            st1 = con.createStatement(); 
		            String sql1 = "DELETE FROM user_table " +  "WHERE username = '" + username + "'";
		            int rs1 = st1.executeUpdate(sql1);
		            
		            if (rs1 == 1)
		            {
		              AdminFrame.this.textField.setText("");            
		              JOptionPane.showMessageDialog(null, "User deleted successfully");
		            }
		            else 
		            {	
		        
                  JOptionPane.showMessageDialog(null, "user doesnt exsist");
		          
		             
		              }
		          }
				 
				 
				 catch (SQLException se)
		          {
		            se.printStackTrace();
		          } catch (ClassNotFoundException e1) {
					
					e1.printStackTrace();
				}
		          
			 
				
			}
		});
		btnDeleteUser.setBounds(328, 217, 115, 23);
		panel_2.add(btnDeleteUser);
		
		JLabel label_1 = new JLabel("");
		Image img1 = new ImageIcon(this.getClass().getResource("/delete.jpg")).getImage();
		label_1.setIcon(new ImageIcon(img1));
		label_1.setBounds(61, 122, 115, 157);
		panel_2.add(label_1);
		
		JPanel Add_expen = new JPanel();
		getContentPane().add(Add_expen, "name_51935305444630");
		Add_expen.setLayout(null);
		
		JLabel lblAddExpenditures = new JLabel("Add Expenditures :");
		lblAddExpenditures.setForeground(Color.BLUE);
		lblAddExpenditures.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblAddExpenditures.setBounds(198, 83, 166, 40);
		Add_expen.add(lblAddExpenditures);
		
		JLabel lblDescription = new JLabel("Description :");
		lblDescription.setBounds(138, 163, 79, 14);
		Add_expen.add(lblDescription);
		
		JLabel lblAmount = new JLabel("Amount :");
		lblAmount.setBounds(138, 204, 56, 14);
		Add_expen.add(lblAmount);
		
		JLabel lblDate = new JLabel("Date :");
		lblDate.setBounds(138, 249, 46, 14);
		Add_expen.add(lblDate);
		
		textField_2 = new JTextField();
		textField_2.setBounds(246, 160, 86, 20);
		Add_expen.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(246, 198, 86, 20);
		Add_expen.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(246, 246, 86, 20);
		Add_expen.add(textField_4);
		textField_4.setColumns(10);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String size1 = AdminFrame.this.textField_2.getText();
		        Integer amo = Integer.valueOf(Integer.parseInt(AdminFrame.this.textField_3.getText()));
		        String da1 = AdminFrame.this.textField_4.getText();
		        
		        Connection con = null;
		        Statement st = null;
		        String url = "jdbc:mysql://localhost:3306/internet_shop";
		        String user = "root";
		        String password = "";
		        try
		        {
		          Class.forName("com.mysql.jdbc.Driver");
		          con = DriverManager.getConnection(url, user, password);
		          st = con.createStatement();
		          
		          String sql = " INSERT INTO expenditures (description,amount,date) VALUES ('" + 
		            size1 + "','" + amo + "','" + da1 + "')";
		          int rs = st.executeUpdate(sql);
		          if (rs == 1)
		          {
		            AdminFrame.this.textField_2.setText("");
		            AdminFrame.this.textField_3.setText("");
		            AdminFrame.this.textField_4.setText("");
		    
		            JOptionPane.showMessageDialog(null, "Added successfully");
		          }
		          else
		          {
		            JOptionPane.showMessageDialog(null, "Something wrong");
		          }
		          st.close();
		          con.close();
		        }
		        catch (SQLException se)
		        {
		          se.printStackTrace();
		        }
		        catch (Exception e1)
		        {
		          e1.printStackTrace();
		        }
		      }
				
				
			
		});
		btnAdd.setBounds(184, 306, 89, 23);
		Add_expen.add(btnAdd);
		
		JLabel lblddmmyyyy = new JLabel("( DD/MM/YYYY )");
		lblddmmyyyy.setBounds(388, 252, 86, 14);
		Add_expen.add(lblddmmyyyy);
		
		JPanel View_expen = new JPanel();
		getContentPane().add(View_expen, "name_54095867463309");
		View_expen.setLayout(null);
		
		JLabel lblViewExpenditures = new JLabel("View Expenditures");
		lblViewExpenditures.setForeground(Color.BLUE);
		lblViewExpenditures.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblViewExpenditures.setBounds(218, 24, 152, 25);
		View_expen.add(lblViewExpenditures);
		
		JLabel lblStartDate = new JLabel("Start date ");
		lblStartDate.setBounds(155, 100, 71, 14);
		View_expen.add(lblStartDate);
		
		textField_5 = new JTextField();
		textField_5.setBounds(260, 97, 86, 20);
		View_expen.add(textField_5);
		textField_5.setColumns(10);
		
		JLabel lblEndDate = new JLabel("End date");
		lblEndDate.setBounds(155, 139, 52, 14);
		View_expen.add(lblEndDate);
		
		textField_6 = new JTextField();
		textField_6.setBounds(260, 136, 86, 20);
		View_expen.add(textField_6);
		textField_6.setColumns(10);
		
		JButton btnNewButton_1 =  new JButton("View Data");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s_date = AdminFrame.this.textField_5.getText();
		        String e_date = AdminFrame.this.textField_6.getText();
		        
		        Connection con = null;
		        Statement st = null;
		        String url = "jdbc:mysql://localhost:3306/internet_shop";
		        String user = "root";
		        String password = "";
		        try
		        {
		          Class.forName("com.mysql.jdbc.Driver");
		          con = DriverManager.getConnection(url, user, password);
		          st = con.createStatement();
		          
		          String sql = " select * from expenditures  where date between   '" + s_date + "'  and '" + e_date + "'";
		          ResultSet rs = st.executeQuery(sql);
		          AdminFrame.this.table_1.setModel(DbUtils.resultSetToTableModel(rs));
		          
		          AdminFrame.this.textField_5.setText("");
		          AdminFrame.this.textField_6.setText("");
		          st.close();
		          con.close();
		        }
		        catch (SQLException se)
		        {
		          se.printStackTrace();
		        }
		        catch (Exception e1)
		        {
		          e1.printStackTrace();
		        }
			}
		});
		btnNewButton_1.setBounds(205, 177, 101, 23);
		View_expen.add(btnNewButton_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(31, 234, 594, 190);
		View_expen.add(scrollPane);
		
		table_1 = new JTable();
		scrollPane.setViewportView(table_1);
		
		JPanel income_add = new JPanel();
		getContentPane().add(income_add, "name_56397118168204");
		income_add.setLayout(null);
		
		JLabel lblAddIncome = new JLabel("Add Income :");
		lblAddIncome.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblAddIncome.setBounds(259, 48, 109, 23);
		income_add.add(lblAddIncome);
		
		JLabel lblTotalAmount = new JLabel("Amount ");
		lblTotalAmount.setBounds(134, 131, 86, 14);
		income_add.add(lblTotalAmount);
		
		textField_7 = new JTextField();
		textField_7.setBounds(281, 128, 86, 20);
		income_add.add(textField_7);
		textField_7.setColumns(10);
		
		JLabel lblDate_1 = new JLabel("Date");
		lblDate_1.setBounds(134, 211, 46, 14);
		income_add.add(lblDate_1);
		
		textField_8 = new JTextField();
		textField_8.setBounds(282, 208, 86, 20);
		income_add.add(textField_8);
		textField_8.setColumns(10);
		
		JButton btnAdd_1 = new JButton("Add");
		btnAdd_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
		        Integer amo = Integer.valueOf(Integer.parseInt(AdminFrame.this.textField_7.getText()));
		        String des = AdminFrame.this.textField_9.getText();
		        String da1 = AdminFrame.this.textField_8.getText();
		        
		        Connection con = null;
		        Statement st = null;
		        String url = "jdbc:mysql://localhost:3306/internet_shop";
		        String user = "root";
		        String password = "";
		        try
		        {
		          Class.forName("com.mysql.jdbc.Driver");
		          con = DriverManager.getConnection(url, user, password);
		          st = con.createStatement();
		          
		          String sql = " INSERT INTO income (amount,description,date) VALUES ('" + 
		            amo + "','" + des + "','" + da1 + "')";
		          int rs = st.executeUpdate(sql);
		          if (rs == 1)
		          {
		            AdminFrame.this.textField_7.setText("");
		            AdminFrame.this.textField_8.setText("");
		            AdminFrame.this.textField_9.setText("");
		    
		            JOptionPane.showMessageDialog(null, "Added successfully");
		          }
		          else
		          {
		            JOptionPane.showMessageDialog(null, "Something wrong");
		          }
		          st.close();
		          con.close();
		        }
		        catch (SQLException se)
		        {
		          se.printStackTrace();
		        }
		        catch (Exception e1)
		        {
		          e1.printStackTrace();
		        }
				
			}
		});
		btnAdd_1.setBounds(199, 258, 89, 23);
		income_add.add(btnAdd_1);
		
		JLabel lblDdmmyyyy = new JLabel("( DD/MM/YYYY )");
		lblDdmmyyyy.setBounds(408, 214, 86, 14);
		income_add.add(lblDdmmyyyy);
		
		JLabel lblDescription_1 = new JLabel("Description");
		lblDescription_1.setBounds(134, 173, 69, 14);
		income_add.add(lblDescription_1);
		
		textField_9 = new JTextField();
		textField_9.setBounds(281, 170, 86, 20);
		income_add.add(textField_9);
		textField_9.setColumns(10);
		
		JPanel income_view = new JPanel();
		getContentPane().add(income_view, "name_56537014371751");
		income_view.setLayout(null);
		
		JLabel lblViewData = new JLabel("View Data");
		lblViewData.setBounds(258, 26, 62, 14);
		income_view.add(lblViewData);
		
		JLabel lblStartDate_1 = new JLabel("Start date ");
		lblStartDate_1.setBounds(196, 83, 62, 14);
		income_view.add(lblStartDate_1);
		
		JLabel lblEndDate_1 = new JLabel("End date");
		lblEndDate_1.setBounds(199, 136, 59, 14);
		income_view.add(lblEndDate_1);
		
		textField_10 = new JTextField();
		textField_10.setBounds(332, 80, 86, 20);
		income_view.add(textField_10);
		textField_10.setColumns(10);
		
		textField_11 = new JTextField();
		textField_11.setBounds(332, 133, 86, 20);
		income_view.add(textField_11);
		textField_11.setColumns(10);
		
		JButton btnView = new JButton("View");
		btnView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String s_date = AdminFrame.this.textField_10.getText();
		        String e_date = AdminFrame.this.textField_11.getText();
		        
		        Connection con = null;
		        Statement st = null;
		        String url = "jdbc:mysql://localhost:3306/internet_shop";
		        String user = "root";
		        String password = "";
		        try
		        {
		          Class.forName("com.mysql.jdbc.Driver");
		          con = DriverManager.getConnection(url, user, password);
		          st = con.createStatement();
		          
		          String sql = " select * from income  where date between   '" + s_date + "'  and '" + e_date + "'";
		          ResultSet rs = st.executeQuery(sql);
		          AdminFrame.this.table.setModel(DbUtils.resultSetToTableModel(rs));
		          
		         
		          st.close();
		          con.close();
		        }
		        catch (SQLException se)
		        {
		          se.printStackTrace();
		        }
		        catch (Exception e1)
		        {
		          e1.printStackTrace();
		        }
				
			}
		});
		btnView.setBounds(266, 178, 89, 23);
		income_view.add(btnView);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 243, 672, 164);
		income_view.add(scrollPane_1);
		
		table = new JTable();
		scrollPane_1.setViewportView(table);
		
		JPanel backup = new JPanel();
		getContentPane().add(backup, "name_59650634978400");
		backup.setLayout(null);
		
		JLabel lblBackupData = new JLabel("Backup data");
		lblBackupData.setForeground(Color.BLUE);
		lblBackupData.setBounds(234, 52, 86, 14);
		backup.add(lblBackupData);
		
		JLabel lblNewLabel = new JLabel("Username ");
		lblNewLabel.setBounds(145, 109, 77, 14);
		backup.add(lblNewLabel);
		
		JLabel lblPassword_1 = new JLabel("Password");
		lblPassword_1.setBounds(145, 146, 61, 14);
		backup.add(lblPassword_1);
		
		JButton btnBackup = new JButton("Backup");
		btnBackup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String username_get = AdminFrame.this.username.getText();
		        String password_get = AdminFrame.this.password.getText();
		        String database_get = AdminFrame.this.database.getText();
		        String path_get = AdminFrame.this.path.getText();
		        String manual_database = "internet_shop.sql";
		        String final_path = " " + path_get + manual_database;
		        try
		        {
		          Process runtimeProcess = Runtime.getRuntime().exec("C:\\xampp\\mysql\\bin\\mysqldump -u  " + username_get + " " + password_get + " " + database_get + " -r " + final_path);
		          
		          int processComplete = runtimeProcess.waitFor();
		          if (processComplete == 1)
		          {
		            JOptionPane.showMessageDialog(null, "Backup Failed");
		          }
		          else if (processComplete == 0)
		          {
		        	  
		        	JOptionPane.showMessageDialog(null, "\n Backup created Successfully..");
		            AdminFrame.this.username.setText("");
		            AdminFrame.this.password.setText("");
		            AdminFrame.this.database.setText("");
		            AdminFrame.this.path.setText("");
		            
		          }
		        }
		        catch (Exception e1)
		        {
		          JOptionPane.showMessageDialog(null, e1);
		        }
			}
		});
		btnBackup.setBounds(197, 267, 89, 23);
		backup.add(btnBackup);
		
		JLabel lblDatabase = new JLabel("Database");
		lblDatabase.setBounds(145, 186, 61, 14);
		backup.add(lblDatabase);
		
		JLabel lblPath = new JLabel("Path");
		lblPath.setBounds(145, 224, 46, 14);
		backup.add(lblPath);
		
		username = new JTextField();
		username.setBounds(278, 106, 86, 20);
		backup.add(username);
		username.setColumns(10);
		
		password = new JTextField();
		password.setBounds(278, 143, 86, 20);
		backup.add(password);
		password.setColumns(10);
		
		database = new JTextField();
		database.setBounds(278, 183, 86, 20);
		backup.add(database);
		database.setColumns(10);
		
		path = new JTextField();
		path.setBounds(278, 221, 86, 20);
		backup.add(path);
		path.setColumns(10);
		
		JPanel License = new JPanel();
		getContentPane().add(License, "name_81876720356599");
		License.setLayout(null);
		
		JLabel lblLicenseInformation = new JLabel("License Information :");
		lblLicenseInformation.setForeground(new Color(128, 128, 0));
		lblLicenseInformation.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblLicenseInformation.setBounds(186, 66, 168, 14);
		License.add(lblLicenseInformation);
		
		JLabel lblLicensedTo = new JLabel("Licensed to ");
		lblLicensedTo.setBounds(170, 131, 91, 14);
		License.add(lblLicensedTo);
		
		JLabel lblSaiInternetShop = new JLabel("Sai Internet shop");
		lblSaiInternetShop.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblSaiInternetShop.setForeground(new Color(139, 0, 0));
		lblSaiInternetShop.setBounds(285, 131, 102, 14);
		License.add(lblSaiInternetShop);
		
		JLabel lblLicenseKey = new JLabel("License Key");
		lblLicenseKey.setBounds(170, 168, 75, 14);
		License.add(lblLicenseKey);
		
		JLabel lblJkghyukfh = new JLabel("JKGHYU560KFH");
		lblJkghyukfh.setForeground(new Color(0, 128, 128));
		lblJkghyukfh.setBounds(287, 168, 100, 14);
		License.add(lblJkghyukfh);
		
		JLabel lblValidUpto = new JLabel("Valid upto");
		lblValidUpto.setBounds(170, 206, 61, 14);
		License.add(lblValidUpto);
		
		JLabel label_2 = new JLabel("22/03/2017");
		label_2.setForeground(new Color(107, 142, 35));
		label_2.setBounds(285, 206, 69, 14);
		License.add(label_2);
		
		JLabel lblNote = new JLabel("Note : The updates and maintanance will be provided till valid date only.");
		lblNote.setForeground(new Color(255, 0, 0));
		lblNote.setBounds(133, 301, 472, 14);
		License.add(lblNote);
		
		JPanel viewusers = new JPanel();
		getContentPane().add(viewusers, "name_83001145966560");
		viewusers.setLayout(null);
		
		JButton btnViewUsers = new JButton("View Users");
		btnViewUsers.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
		        
		        Connection con = null;
		        Statement st = null;
		        String url = "jdbc:mysql://localhost:3306/internet_shop";
		        String user = "root";
		        String password = "";
		        try
		        {
		          Class.forName("com.mysql.jdbc.Driver");
		          con = DriverManager.getConnection(url, user, password);
		          st = con.createStatement();
		          
		          String sql = " select * from user_table";
		          ResultSet rs = st.executeQuery(sql);
		          AdminFrame.this.table_2.setModel(DbUtils.resultSetToTableModel(rs));
		          
		         
		          st.close();
		          con.close();
		        }
		        catch (SQLException se)
		        {
		          se.printStackTrace();
		        }
		        catch (Exception e1)
		        {
		          e1.printStackTrace();
		        }
				
				
				
			}
		});
		btnViewUsers.setBounds(251, 65, 100, 23);
		viewusers.add(btnViewUsers);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(41, 173, 593, 222);
		viewusers.add(scrollPane_2);
		
		table_2 = new JTable();
		scrollPane_2.setViewportView(table_2);
		
		
	}
}
