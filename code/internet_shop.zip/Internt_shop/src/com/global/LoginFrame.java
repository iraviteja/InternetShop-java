package com.global;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class LoginFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginFrame frame = new LoginFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginFrame() {
		
		setTitle("Internet shop management system");
	    setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 392, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblUsername = new JLabel("Username :");
		lblUsername.setBounds(68, 104, 76, 14);
		contentPane.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password :");
		lblPassword.setBounds(72, 157, 72, 14);
		contentPane.add(lblPassword);
		
		textField = new JTextField();
		textField.setBounds(162, 101, 86, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(162, 154, 86, 20);
		contentPane.add(passwordField);
		
		JLabel lblPoweredBySyzant = new JLabel("Powered by Syzant");
		lblPoweredBySyzant.setForeground(Color.BLUE);
		lblPoweredBySyzant.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblPoweredBySyzant.setBounds(10, 246, 134, 14);
		contentPane.add(lblPoweredBySyzant);
		
		JLabel lblEnterYourLogin = new JLabel("Enter your login details");
		lblEnterYourLogin.setForeground(Color.MAGENTA);
		lblEnterYourLogin.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblEnterYourLogin.setBounds(91, 43, 180, 20);
		contentPane.add(lblEnterYourLogin);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				String username = LoginFrame.this.textField.getText();
		        String pass = String.valueOf(LoginFrame.this.passwordField.getPassword());
		        if (username.equals("admin"))
		        {
		          Connection con = null;
		          Statement st = null;
		          String url = "jdbc:mysql://localhost:3306/internet_shop";
		          String user = "root";
		          String password = "";
		          try
		          {
		            Class.forName("com.mysql.jdbc.Driver");
		            con = DriverManager.getConnection(url, user, password);
		            st = con.createStatement();
		            
		            String sql = "SELECT username , password FROM admin_table WHERE username = '" + username + "' AND password = '" + pass + "' ";
		            ResultSet rs = st.executeQuery(sql);
		            if (rs.next())
		            {
		              new AdminFrame().setVisible(true);
		              LoginFrame.this.dispose();
		            }
		            else if (!rs.next())
		            {
		              JOptionPane.showMessageDialog(null, "Sorry Wrong credentials");
		            }
		            rs.close();
		            st.close();
		            con.close();
		          }
		          catch (SQLException se)
		          {
		            se.printStackTrace();
		          }
		          catch (Exception e)
		          {
		            e.printStackTrace();
		          }
		        }
		        else
		        {
		          Connection con = null;
		          Statement st = null;
		          String url = "jdbc:mysql://localhost:3306/internet_shop";
		          String user = "root";
		          String password = "";
		          try
		          {
		            Class.forName("com.mysql.jdbc.Driver");
		            con = DriverManager.getConnection(url, user, password);
		            st = con.createStatement();
		            
		            String sql = "SELECT username , password FROM user_table WHERE username = '" + username + "' AND password = '" + pass + "' ";
		            ResultSet rs = st.executeQuery(sql);
		            if (rs.next())
		            {
		              new UserFrame().setVisible(true);
		              LoginFrame.this.dispose();
		            }
		            else if (!rs.next())
		            {
		              JOptionPane.showMessageDialog(null, "Sorry Wrong credentials");
		            }
		            rs.close();
		            st.close();
		            con.close();
		          }
		          catch (SQLException se)
		          {
		            se.printStackTrace();
		          }
		          catch (Exception e)
		          {
		            e.printStackTrace();
		          }
		        }
				
				
				
			}
		});
		btnLogin.setBounds(143, 199, 66, 23);
		contentPane.add(btnLogin);
	}
}
