package com.global;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.CardLayout;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class UserFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static int status = 0;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTable table;
	private JTextField textField_10;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserFrame frame = new UserFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UserFrame() {
		setTitle("Internet Shop Management");
	    setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 665, 486);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("Navigation");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmMainpage = new JMenuItem("Mainpage");
		mntmMainpage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				
				((CardLayout)UserFrame.this.getContentPane().getLayout()).show(UserFrame.this.getContentPane(), "name_348918116231875");
				
			}
		});
		mnNewMenu.add(mntmMainpage);
		
		JMenuItem mntmExit = new JMenuItem("Exit");
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				System.exit(0);
			}
		});
		mnNewMenu.add(mntmExit);
		
		JMenu mnExpenditures = new JMenu("Expenditures");
		menuBar.add(mnExpenditures);
		
		JMenuItem mntmAddExpenditures = new JMenuItem("Add expenditures");
		mntmAddExpenditures.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				((CardLayout)UserFrame.this.getContentPane().getLayout()).show(UserFrame.this.getContentPane(), "name_349813489389147");
				
			}
		});
		mnExpenditures.add(mntmAddExpenditures);
		
		JMenu mnIncome = new JMenu("Income");
		menuBar.add(mnIncome);
		
		JMenuItem mntmAddIncome = new JMenuItem("Add income");
		mntmAddIncome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				((CardLayout)UserFrame.this.getContentPane().getLayout()).show(UserFrame.this.getContentPane(), "name_349871564723170");
			}
		});
		mnIncome.add(mntmAddIncome);
		
		JMenu mnSystemSettings = new JMenu("System Settings");
		menuBar.add(mnSystemSettings);
		
		JMenuItem mntmAdddeleteSystems = new JMenuItem("Add/delete systems");
		mntmAdddeleteSystems.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				((CardLayout)UserFrame.this.getContentPane().getLayout()).show(UserFrame.this.getContentPane(), "name_349886974319356");
			}
		});
		mnSystemSettings.add(mntmAdddeleteSystems);
		
		JMenu menu = new JMenu("");
		menuBar.add(menu);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new CardLayout(0, 0));
		
		JPanel mainpage = new JPanel();
		contentPane.add(mainpage, "name_348918116231875");
		mainpage.setLayout(null);
		
		JLabel lblSessionStart = new JLabel("Session Start");
		lblSessionStart.setForeground(Color.BLUE);
		lblSessionStart.setBounds(85, 67, 104, 14);
		mainpage.add(lblSessionStart);
		
		JLabel lblName = new JLabel("Name :");
		lblName.setBounds(20, 124, 57, 14);
		mainpage.add(lblName);
		
		textField_8 = new JTextField();
		textField_8.setBounds(108, 121, 86, 20);
		mainpage.add(textField_8);
		textField_8.setColumns(10);
		
		JLabel lblSystemNo_2 = new JLabel("System no :");
		lblSystemNo_2.setBounds(20, 171, 77, 14);
		mainpage.add(lblSystemNo_2);
		
		JButton btnStartSession = new JButton("Start session");
		btnStartSession.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String name = UserFrame.this.textField_8.getText();
		        Integer sys_no = Integer.valueOf(Integer.parseInt(UserFrame.this.textField_9.getText()));
		        String timeStamp = new SimpleDateFormat("HHmm").format(Calendar.getInstance().getTime());
		        
		        Connection con = null;
		        Statement st = null;
		        String url = "jdbc:mysql://localhost:3306/internet_shop";
		        String user = "root";
		        String password = "";
		        try
		        {
		          Class.forName("com.mysql.jdbc.Driver");
		          con = DriverManager.getConnection(url, user, password);
		          st = con.createStatement();
		          
		          String sql = " INSERT INTO activ_sys (name,system_no,time) VALUES ('" + 
		            name + "','" + sys_no + "','" + timeStamp + "')";
		          int rs = st.executeUpdate(sql);
		          if (rs == 1)
		          {
		        	  
		        	  Class.forName("com.mysql.jdbc.Driver");
			          con = DriverManager.getConnection(url, user, password);
			          st = con.createStatement();
			          
			          String sql1 = " DELETE FROM systems WHERE NUMBER=" + sys_no ;
			          int rs1 = st.executeUpdate(sql1);
		        	  
		       if(rs1==1)
		       {
		    	   
		       }
		            UserFrame.this.textField_8.setText("");
		            UserFrame.this.textField_9.setText("");
		          
		    
		            JOptionPane.showMessageDialog(null, "session started successfully");
		            
		          }
		          else
		          {
		            JOptionPane.showMessageDialog(null, "Something wrong");
		          }
		          st.close();
		          con.close();
		        }
		        catch (SQLException se)
		        {
		          se.printStackTrace();
		        }
		        catch (Exception e1)
		        {
		          e1.printStackTrace();
		        }
				
				
			}
		});
		btnStartSession.setBounds(50, 215, 128, 23);
		mainpage.add(btnStartSession);
		
		textField_9 = new JTextField();
		textField_9.setBounds(107, 168, 86, 20);
		mainpage.add(textField_9);
		textField_9.setColumns(10);
		
		JButton btnCheck = new JButton("Check");
		btnCheck.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Connection con = null;
		        Statement st = null;
		        String url = "jdbc:mysql://localhost:3306/internet_shop";
		        String user = "root";
		        String password = "";
		        try
		        {
		          Class.forName("com.mysql.jdbc.Driver");
		          con = DriverManager.getConnection(url, user, password);
		          st = con.createStatement();
		          
		          String sql = " select * from systems";
		          ResultSet rs = st.executeQuery(sql);
		          UserFrame.this.table.setModel(DbUtils.resultSetToTableModel(rs));
		          
		          
		          st.close();
		          con.close();
		        }
		        catch (SQLException se)
		        {
		          se.printStackTrace();
		        }
		        catch (Exception e1)
		        {
		          e1.printStackTrace();
		        }
				
			}
		});
		btnCheck.setBounds(151, 271, 89, 23);
		mainpage.add(btnCheck);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 305, 220, 93);
		mainpage.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		JLabel lblSessionStop = new JLabel("Session Stop");
		lblSessionStop.setForeground(Color.BLUE);
		lblSessionStop.setBounds(467, 67, 77, 14);
		mainpage.add(lblSessionStop);
		
		JLabel lblSystemno = new JLabel("System_no : ");
		lblSystemno.setBounds(404, 124, 77, 14);
		mainpage.add(lblSystemno);
		
		textField_10 = new JTextField();
		textField_10.setBounds(511, 121, 86, 20);
		mainpage.add(textField_10);
		textField_10.setColumns(10);
		
		JLabel lblAvailableSystems = new JLabel("Available systems :");
		lblAvailableSystems.setForeground(Color.MAGENTA);
		lblAvailableSystems.setBounds(20, 280, 110, 14);
		mainpage.add(lblAvailableSystems);
		
		JButton btnDelete_1 = new JButton("Delete");
		btnDelete_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
                Integer sys = Integer.valueOf(Integer.parseInt(UserFrame.this.textField_10.getText()));

		        Connection con = null;
		        Statement st = null;
		        String url = "jdbc:mysql://localhost:3306/internet_shop";
		        String user = "root";
		        String password = "";
		        try
		        {
		          Class.forName("com.mysql.jdbc.Driver");
		          con = DriverManager.getConnection(url, user, password);
		          st = con.createStatement();
		          
                  String sql1 = " INSERT INTO systems (number) VALUES ('" + sys + "')" ;
		          int rs1= st.executeUpdate(sql1);
		          if(rs1==1)
		          {
					  
					  
                  String sql2 = "SELECT time FROM activ_sys WHERE system_no="+sys;
		          ResultSet rs2 = st.executeQuery(sql2);
		          
		          if (rs2.next())
		          {
		            int status = rs2.getInt("time");
		            String timeStamp = new SimpleDateFormat("HHmm").format(Calendar.getInstance().getTime());
		            Integer timeStamp1 = Integer.parseInt(timeStamp);
		            Integer status1 = timeStamp1 - status ;
		            JOptionPane.showMessageDialog(null, "Used minutes are" +status1);
		          }
		          
		          else 
		        	  
		          {
		        	  JOptionPane.showMessageDialog(null, "So");
		          }
					  
					  
					  
	                String sql = " DELETE FROM activ_sys WHERE system_no=" + sys ;
	                int rs = st.executeUpdate(sql);
	                if(rs==1)
	                {
	                	
	                }
					  
	                UserFrame.this.textField_10.setText("");
	  
		          }
				  

				  
				  
				 else 
					 
					 {
						 JOptionPane.showMessageDialog(null, "Sorry something wrong");
						 
						 
					 }
		          st.close();
		          con.close();
		        }
		        catch (SQLException se)
		        {
		          se.printStackTrace();
		        }
		        catch (Exception e1)
		        {
		          e1.printStackTrace();
		        }
		       
			} 
		});
		btnDelete_1.setBounds(457, 167, 89, 23);
		mainpage.add(btnDelete_1);
		
		JLabel lblPoweredBy = new JLabel("Powered By");
		lblPoweredBy.setBounds(485, 303, 112, 14);
		mainpage.add(lblPoweredBy);
		
		JLabel lblSyzant = new JLabel("SYZANT");
		lblSyzant.setForeground(Color.BLUE);
		lblSyzant.setBounds(495, 328, 62, 14);
		mainpage.add(lblSyzant);
		
		JPanel expenditures = new JPanel();
		contentPane.add(expenditures, "name_349813489389147");
		expenditures.setLayout(null);
		
		JLabel lblAddExpenditures = new JLabel("Add Expenditures");
		lblAddExpenditures.setForeground(Color.BLUE);
		lblAddExpenditures.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblAddExpenditures.setBounds(197, 67, 148, 20);
		expenditures.add(lblAddExpenditures);
		
		JLabel lblDescription = new JLabel("Description :");
		lblDescription.setBounds(116, 148, 78, 14);
		expenditures.add(lblDescription);
		
		textField = new JTextField();
		textField.setBounds(243, 145, 86, 20);
		expenditures.add(textField);
		textField.setColumns(10);
		
		JLabel lblAmount = new JLabel("Amount :");
		lblAmount.setBounds(116, 196, 67, 14);
		expenditures.add(lblAmount);
		
		textField_1 = new JTextField();
		textField_1.setBounds(243, 193, 86, 20);
		expenditures.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblDate = new JLabel("Date :");
		lblDate.setBounds(116, 244, 46, 14);
		expenditures.add(lblDate);
		
		textField_2 = new JTextField();
		textField_2.setBounds(243, 241, 86, 20);
		expenditures.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("( dd/mm/yyyy )");
		lblNewLabel.setBounds(384, 244, 106, 14);
		expenditures.add(lblNewLabel);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String size1 = UserFrame.this.textField.getText();
		        Integer amo = Integer.valueOf(Integer.parseInt(UserFrame.this.textField_1.getText()));
		        String da1 = UserFrame.this.textField_2.getText();
		        
		        Connection con = null;
		        Statement st = null;
		        String url = "jdbc:mysql://localhost:3306/internet_shop";
		        String user = "root";
		        String password = "";
		        try
		        {
		          Class.forName("com.mysql.jdbc.Driver");
		          con = DriverManager.getConnection(url, user, password);
		          st = con.createStatement();
		          
		          String sql = " INSERT INTO expenditures (description,amount,date) VALUES ('" + 
		            size1 + "','" + amo + "','" + da1 + "')";
		          int rs = st.executeUpdate(sql);
		          if (rs == 1)
		          {
		            UserFrame.this.textField.setText("");
		            UserFrame.this.textField_1.setText("");
		            UserFrame.this.textField_2.setText("");
		    
		            JOptionPane.showMessageDialog(null, "Added successfully");
		          }
		          else
		          {
		            JOptionPane.showMessageDialog(null, "Something wrong");
		          }
		          st.close();
		          con.close();
		        }
		        catch (SQLException se)
		        {
		          se.printStackTrace();
		        }
		        catch (Exception e1)
		        {
		          e1.printStackTrace();
		        }
				
			}
		});
		btnAdd.setBounds(197, 297, 89, 23);
		expenditures.add(btnAdd);
		
		
		
		JPanel income = new JPanel();
		contentPane.add(income, "name_349871564723170");
		income.setLayout(null);
		
		JLabel lblAddIncome = new JLabel("Add income");
		lblAddIncome.setForeground(Color.BLUE);
		lblAddIncome.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblAddIncome.setBounds(192, 66, 128, 19);
		income.add(lblAddIncome);
		
		JLabel lblAmount_1 = new JLabel("Amount");
		lblAmount_1.setBounds(142, 131, 46, 14);
		income.add(lblAmount_1);
		
		textField_3 = new JTextField();
		textField_3.setBounds(255, 128, 86, 20);
		income.add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblDescription_1 = new JLabel("Description");
		lblDescription_1.setBounds(142, 177, 70, 14);
		income.add(lblDescription_1);
		
		textField_4 = new JTextField();
		textField_4.setBounds(255, 174, 86, 20);
		income.add(textField_4);
		textField_4.setColumns(10);
		
		JLabel lblDate_1 = new JLabel("Date");
		lblDate_1.setBounds(142, 222, 46, 14);
		income.add(lblDate_1);
		
		textField_5 = new JTextField();
		textField_5.setBounds(255, 219, 86, 20);
		income.add(textField_5);
		textField_5.setColumns(10);
		
		JButton btnSubmit = new JButton("Submit");
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				    Integer amo = Integer.valueOf(Integer.parseInt(UserFrame.this.textField_3.getText()));
			        String des = UserFrame.this.textField_5.getText();
			        String da1 = UserFrame.this.textField_4.getText();
			        
			        Connection con = null;
			        Statement st = null;
			        String url = "jdbc:mysql://localhost:3306/internet_shop";
			        String user = "root";
			        String password = "";
			        try
			        {
			          Class.forName("com.mysql.jdbc.Driver");
			          con = DriverManager.getConnection(url, user, password);
			          st = con.createStatement();
			          
			          String sql = " INSERT INTO income (amount,description,date) VALUES ('" + 
			            amo + "','" + des + "','" + da1 + "')";
			          int rs = st.executeUpdate(sql);
			          if (rs == 1)
			          {
			            UserFrame.this.textField_3.setText("");
			            UserFrame.this.textField_4.setText("");
			            UserFrame.this.textField_5.setText("");
			    
			            JOptionPane.showMessageDialog(null, "Added successfully");
			          }
			          else
			          {
			            JOptionPane.showMessageDialog(null, "Something wrong");
			          }
			          st.close();
			          con.close();
			        }
			        catch (SQLException se)  
			        {
			          se.printStackTrace();
			        }
			        catch (Exception e1)
			        {
			          e1.printStackTrace();
			        }
					
			}
		});
		btnSubmit.setBounds(205, 274, 89, 23);
		income.add(btnSubmit);
		
		JLabel lblDdmmyyyy = new JLabel("( dd/mm/yyyy )");
		lblDdmmyyyy.setBounds(400, 222, 80, 14);
		income.add(lblDdmmyyyy);
		
		JPanel system = new JPanel();
		contentPane.add(system, "name_349886974319356");
		system.setLayout(null);
		
		JLabel lblAddSystem = new JLabel("Add system");
		lblAddSystem.setForeground(Color.BLUE);
		lblAddSystem.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblAddSystem.setBounds(64, 100, 109, 14);
		system.add(lblAddSystem);
		
		JLabel lblDeleteSystem = new JLabel("Delete system");
		lblDeleteSystem.setForeground(Color.BLUE);
		lblDeleteSystem.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblDeleteSystem.setBounds(433, 101, 93, 14);
		system.add(lblDeleteSystem);
		
		textField_6 = new JTextField();
		textField_6.setBounds(114, 166, 86, 20);
		system.add(textField_6);
		textField_6.setColumns(10);
		
		JLabel lblSystemNo = new JLabel("System no");
		lblSystemNo.setBounds(21, 169, 66, 14);
		system.add(lblSystemNo);
		
		JButton btnAdd_1 = new JButton("Add");
		btnAdd_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
		        Integer sys = Integer.valueOf(Integer.parseInt(UserFrame.this.textField_6.getText()));
		        
		        
		        Connection con = null;
		        Statement st = null;
		        String url = "jdbc:mysql://localhost:3306/internet_shop";
		        String user = "root";
		        String password = "";
		        try
		        {
		          Class.forName("com.mysql.jdbc.Driver");
		          con = DriverManager.getConnection(url, user, password);
		          st = con.createStatement();
		          
		          String sql = " INSERT INTO systems (number) VALUES ('" + 
		           sys  + "')";
		          int rs = st.executeUpdate(sql);
		          if (rs == 1)
		          {
		            UserFrame.this.textField_6.setText("");
		          
		    
		            JOptionPane.showMessageDialog(null, "Added successfully");
		          }
		          else
		          {
		            JOptionPane.showMessageDialog(null, "Something wrong");
		          }
		          st.close();
		          con.close();
		        }
		        catch (SQLException se)
		        {
		          se.printStackTrace();
		        }
		        catch (Exception e1)
		        {
		          e1.printStackTrace();
		        }
			}
		});
		btnAdd_1.setBounds(64, 219, 89, 23);
		system.add(btnAdd_1);
		
		JLabel lblSystemNo_1 = new JLabel("System no");
		lblSystemNo_1.setBounds(377, 169, 77, 14);
		system.add(lblSystemNo_1);
		
		textField_7 = new JTextField();
		textField_7.setBounds(491, 166, 86, 20);
		system.add(textField_7);
		textField_7.setColumns(10);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				

		        Integer sys = Integer.valueOf(Integer.parseInt(UserFrame.this.textField_7.getText()));
		        
		        
		        Connection con = null;
		        Statement st = null;
		        String url = "jdbc:mysql://localhost:3306/internet_shop";
		        String user = "root";
		        String password = "";
		        try
		        {
		          Class.forName("com.mysql.jdbc.Driver");
		          con = DriverManager.getConnection(url, user, password);
		          st = con.createStatement();
		          
		          String sql = " DELETE FROM systems WHERE NUMBER=" + sys ;
		          int rs = st.executeUpdate(sql);
		          if (rs == 1)

		          {
		            UserFrame.this.textField_7.setText("");
		          
		    
		            JOptionPane.showMessageDialog(null, "deleted successfully");
		          }
		          else
		          {
		            JOptionPane.showMessageDialog(null, "Something wrong");
		          }
		          st.close();
		          con.close();
		        }
		        catch (SQLException se)
		        {
		          se.printStackTrace();
		        }
		        catch (Exception e1)
		        {
		          e1.printStackTrace();
		        }
				
			}
		});
		btnDelete.setBounds(456, 219, 89, 23);
		system.add(btnDelete);
	}
}
